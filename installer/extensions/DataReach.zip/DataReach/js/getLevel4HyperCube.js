var varLvl4Data = {
	"qInitialDataFetch": [
		{
			"qHeight": 1000,
			"qWidth": 1
		}
	],
	"qDimensions": [
		{
			"qDef": {
				"qFieldDefs": [
					"Application User with Access"
				],
			    "qFieldLabels": [
			      "Title"
			    ],
			    "qSortCriterias": [
			      {
			        "qSortByAscii": 1
			      }
			    ]
			},
			"qNullSuppression": true
		}
	],
	"qMeasures": [],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
}