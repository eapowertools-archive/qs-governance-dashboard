var varLvl1Data = {
	"qInitialDataFetch": [
		{
			"qHeight": 1000,
			"qWidth": 3
		}
	],
	"qDimensions": [
		{
			"qDef": {
				"qFieldDefs": [
					"libName"
				],
			    "qFieldLabels": [
			      "Title"
			    ],
			    "qSortCriterias": [
			      {
			        "qSortByAscii": 1
			      }
			    ]
			},
			"qNullSuppression": true
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Connection Type"
				]
			}
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Connection String"
				]
			}
		}
	],
	"qMeasures": [],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
}