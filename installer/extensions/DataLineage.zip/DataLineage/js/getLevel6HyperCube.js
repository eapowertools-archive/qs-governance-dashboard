var varLvl6Data = {
	"qInitialDataFetch": [
		{
			"qHeight": 1000,
			"qWidth": 6
		}
	],
	"qDimensions": [
		{
			"qDef": {
				"qFieldDefs": [
					"Sheet Id"
				],
			    "qFieldLabels": [
			      "Sheet Id"
			    ]
			},
			"qNullSuppression": true
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Sheet Title"
				],
			    "qFieldLabels": [
			      "Title"
			    ],
			    "qSortCriterias": [
			      {
			        "qSortByAscii": 1
			      }
			    ]
			},
			"qNullSuppression": true
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Sheet Id"
				]
			}
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Sheet Description"
				]
			}
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Sheet Owner by Username"
				]
			}
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Sheet Published"
				]
			}
		}
	],
	"qMeasures": [],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
}