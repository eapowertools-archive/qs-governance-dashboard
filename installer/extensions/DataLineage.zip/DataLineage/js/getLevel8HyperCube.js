var varLvl8Data = {
	"qInitialDataFetch": [
		{
			"qHeight": 1000,
			"qWidth": 5
		}
	],
	"qDimensions": [
		{
			"qDef": {
				"qFieldDefs": [
					"Story Id"
				],
			    "qFieldLabels": [
			      "Story Id"
			    ]
			},
			"qNullSuppression": true
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Story Title"
				],
			    "qFieldLabels": [
			      "Title"
			    ],
			    "qSortCriterias": [
			      {
			        "qSortByAscii": 1
			      }
			    ]
			},
			"qNullSuppression": true
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Story Description"
				]
			}
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Story Owner by Username"
				]
			}
		},
		{
			"qDef": {
				"qFieldDefs": [
					"Story Published"
				]
			}
		}
	],
	"qMeasures": [],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
}